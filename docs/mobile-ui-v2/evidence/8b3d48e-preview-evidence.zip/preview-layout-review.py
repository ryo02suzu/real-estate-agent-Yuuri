import asyncio
import json
import os
import platform
import re
import time
from pathlib import Path
from urllib.parse import urlsplit

from playwright.async_api import async_playwright

OUT = Path("flight-review")
OUT.mkdir(exist_ok=True)
URL = os.environ["REVIEW_URL"]
assert URL.startswith("https://") and URL == os.environ["PREVIEW_URL"]
ADDRESS = "東京都新宿区西新宿2丁目8番1号"  # 東京都庁（公開施設）
FLIGHT = '[role="dialog"].app-touch'
AUTH_COOKIES = []
REPORT = {"sha": os.environ["REVIEW_SHA"], "url": URL,
          "preview_url": os.environ["PREVIEW_URL"], "deployment_tested": True,
          "real_iphone": False, "os": platform.platform(), "checks": []}


async def capture(page, name, record):
    await page.screenshot(path=str(OUT / f"{name}.png"), full_page=True)
    record["text"] = (await page.locator("body").inner_text())[:16000]
    record["layout"] = await page.evaluate("""() => ({
      width:innerWidth,height:innerHeight,scrollWidth:document.documentElement.scrollWidth,
      horizontalOverflow:document.documentElement.scrollWidth>innerWidth+1,
      maps:[...document.querySelectorAll('.maplibregl-map')].map(e=>({box:e.getBoundingClientRect().toJSON(),canvases:[...e.querySelectorAll('canvas')].map(c=>({box:c.getBoundingClientRect().toJSON(),width:c.width,height:c.height}))})),
      controls:[...document.querySelectorAll('button,a,input')].filter(e=>e.getBoundingClientRect().width>0).map(e=>({name:e.getAttribute('aria-label')||e.innerText||e.id,box:e.getBoundingClientRect().toJSON(),fontSize:getComputedStyle(e).fontSize})),
      focus:{tag:document.activeElement?.tagName,name:document.activeElement?.getAttribute('aria-label'),inFlight:!!document.activeElement?.closest('[role="dialog"].app-touch')}
    })""")


async def observe(context, page, record):
    record["page_errors"] = []
    record["failed_requests"] = []
    page.on("pageerror", lambda e: record["page_errors"].append(str(e)[:1500]))
    page.on("requestfailed", lambda r: record["failed_requests"].append({"url": r.url, "failure": r.failure}))
    await context.add_init_script("""(() => {
      window.__flightSeen=false;
      new MutationObserver(()=>{if(document.querySelector('[role="dialog"].app-touch'))window.__flightSeen=true}).observe(document,{subtree:true,childList:true});
    })()""")


async def home(page, width):
    response = await page.goto(URL, wait_until="domcontentloaded", timeout=40000)
    assert response and response.status == 200
    field = page.get_by_label("住所・地番", exact=True) if width < 1024 else page.locator("input#address")
    await field.wait_for(state="visible", timeout=20000)
    await page.evaluate("document.fonts.ready")
    return field


async def submit(page, field):
    await field.fill(ADDRESS)
    await page.get_by_role("button", name="調べる", exact=True).click()


async def check_mobile_layout(page, field, record):
    box = await page.locator(".home-search > div").first.bounding_box()
    area = await page.locator("[data-scroller]").bounding_box()
    assert box and area and box["y"] >= area["y"] - 1 and box["y"] + box["height"] <= area["y"] + area["height"] + 1, "Search is clipped by the viewport or bottom navigation"
    await field.fill(ADDRESS)
    targets = []
    for name in ["入力を消す", "調べる"]:
        button = page.get_by_role("button", name=name, exact=True)
        b = await button.bounding_box()
        assert b and b["width"] >= 43.99 and b["height"] >= 43.99, f"{name} target is smaller than 44px"
        assert await button.evaluate("e => { const r=e.getBoundingClientRect();return e.contains(document.elementFromPoint(r.x+r.width/2,r.y+r.height/2)); }"), f"{name} is obscured"
        targets.append({"name":name,"box":b})
    record["search_targets"] = targets
    await field.fill("")


async def case(browser, engine, name, width=390, height=844, mode="home"):
    record = {"name": name, "browser": engine, "browser_version": browser.version, "mode": mode}
    REPORT["checks"].append(record)
    options = {"viewport": {"width": width, "height": height}, "locale": "ja-JP",
               "device_scale_factor": 1, "is_mobile": width < 1024, "has_touch": width < 1024}
    if mode == "reduced_initial":
        options["reduced_motion"] = "reduce"
    ctx = await browser.new_context(**options, storage_state={"cookies": AUTH_COOKIES, "origins": []})
    if mode == "motion_off":
        await ctx.add_init_script("localStorage.setItem('michilu:motion','off')")
    page = await ctx.new_page()
    await observe(ctx, page, record)
    if mode == "tile_failure":
        await page.route("https://gibs.earthdata.nasa.gov/**", lambda route: route.abort())
        await page.route("https://cyberjapandata.gsi.go.jp/xyz/seamlessphoto/**", lambda route: route.abort())
    try:
        field = await home(page, width)
        await page.wait_for_timeout(1400)
        await capture(page, name + "-home", record)
        record["home_layout"] = record["layout"]
        assert not record["layout"]["horizontalOverflow"], "Horizontal overflow on home"
        assert not record["page_errors"], "Uncaught JavaScript exception on home"
        if width < 1024:
            await check_mobile_layout(page, field, record)
        if mode == "home":
            if width > height and width < 1024:
                example = page.get_by_role("button", name="住所で調べる（例：渋谷区神南1-19-11）", exact=True)
                await example.scroll_into_view_if_needed()
                await capture(page, name + "-scrolled", record)
                assert await example.evaluate("e => {const r=e.getBoundingClientRect(),s=document.querySelector('[data-scroller]').getBoundingClientRect();return r.top>=s.top-1&&r.bottom<=s.bottom+1;}"), "Landscape content cannot be reached by scrolling"
            record["status"] = "passed"
            return
        if mode == "text200":
            # Computed-font simulation only; this is NOT iOS Dynamic Type / browser zoom.
            await page.evaluate("""() => {const e=[...document.querySelectorAll('body *')];const s=e.map(x=>parseFloat(getComputedStyle(x).fontSize));e.forEach((x,i)=>x.style.setProperty('font-size',(s[i]*2)+'px','important'))}""")
            await capture(page, name + "-text200-simulation", record)
            assert not record["layout"]["horizontalOverflow"], "Horizontal overflow with 200% text simulation"
            record["text_fit"] = await page.evaluate("""() => {
              const heading=[...document.querySelectorAll('p')].find(e=>e.textContent.includes('不動産の現場に'));
              const s=getComputedStyle(heading);
              const labels=[...document.querySelectorAll('nav[aria-label="画面の切り替え"] button > span:not([aria-hidden])')];
              return {headingLineHeight:parseFloat(s.lineHeight),headingFontSize:parseFloat(s.fontSize),navLabelsFit:labels.every(e=>{const r=e.getBoundingClientRect(),b=e.parentElement.getBoundingClientRect();return e.scrollWidth<=e.clientWidth+1&&r.left>=b.left-1&&r.right<=b.right+1&&r.bottom<=b.bottom+1})};
            }""")
            assert record["text_fit"]["headingLineHeight"] >= record["text_fit"]["headingFontSize"] * 1.2, "Enlarged heading lines overlap"
            assert record["text_fit"]["navLabelsFit"], "Enlarged navigation labels are clipped"
            record["status"] = "captured_text_simulation"
            return
        if mode == "keyboard":
            await field.focus()
            await page.set_viewport_size({"width": 390, "height": 430})
            await page.wait_for_timeout(250)
            await check_mobile_layout(page, field, record)
            await field.fill(ADDRESS)
            await capture(page, name + "-keyboard-viewport-simulation", record)
            assert await page.get_by_role("button", name="調べる", exact=True).is_visible()
            record["status"] = "captured_viewport_simulation"
            return

        started = time.monotonic()
        await submit(page, field)
        flight = page.locator(FLIGHT)
        if mode in ["reduced_initial", "motion_off"]:
            await page.wait_for_timeout(8000)
            record["flight_seen"] = await page.evaluate("window.__flightSeen")
            await capture(page, name + "-result", record)
            assert not record["flight_seen"], "Flight ran despite motion preference"
            record["status"] = "passed"
            return

        await flight.wait_for(state="visible", timeout=10000)
        record["flight_seen"] = True
        if mode in ["escape", "skip_enter", "skip_space", "reduced_during"]:
            record["skip_buttons"] = await flight.get_by_role("button").count()
            skip = flight.get_by_role("button", name="スキップ", exact=True)
            assert await skip.count() == 1, "No accessible Skip button"
            record["skip_box"] = await skip.bounding_box()
            assert record["skip_box"]["width"] >= 44 and record["skip_box"]["height"] >= 44, "Skip target is smaller than 44px"
            for key in ["Tab", "Tab", "Shift+Tab"]:
                await page.keyboard.press(key)
                assert await page.evaluate("!!document.activeElement?.closest('[role=dialog].app-touch')"), "Focus escaped from flight"
            await page.locator("[data-scroller]").evaluate("e => e.focus()")
            record["focus_in_flight"] = await page.evaluate("!!document.activeElement?.closest('[role=dialog].app-touch')")
            assert record["focus_in_flight"], "Background is not inert during flight"
            if mode == "escape":
                await page.keyboard.press("Escape")
            elif mode in ["skip_enter", "skip_space"]:
                await page.keyboard.press("Enter" if mode == "skip_enter" else "Space")
            else:
                await page.emulate_media(reduced_motion="reduce")
            await page.wait_for_timeout(750)
            record["still_visible"] = await flight.is_visible()
            await capture(page, name + "-after-action", record)
            assert not record["still_visible"], f"Flight did not stop after {mode}"
            record["focus_restored"] = await page.evaluate("document.activeElement?.matches('[data-scroller]')")
            assert record["focus_restored"], "Focus was not returned to investigation content"
            if mode == "reduced_during":
                assert await page.locator(".flight-arrive").count() == 0, "Landing animation ran despite reduced motion"
        elif mode == "touch_skip":
            await page.touchscreen.tap(width / 2, height / 2)
            await flight.wait_for(state="hidden", timeout=2000)
            record["dismissed_seconds"] = round(time.monotonic() - started, 3)
            await capture(page, name + "-skipped", record)
        else:
            record["frames"] = []
            for index, delay in enumerate([400, 1200, 1600, 1800]):
                await page.wait_for_timeout(delay)
                frame = {}
                await capture(page, name + f"-flight-{index}", frame)
                frame["elapsed_seconds"] = round(time.monotonic() - started, 3)
                frame["dialog_visible"] = await flight.is_visible()
                record["frames"].append(frame)
            await flight.wait_for(state="hidden", timeout=17000)
            record["finished_seconds"] = round(time.monotonic() - started, 3)
            if mode == "normal":
                canvases = [c for f in record["frames"] if f["dialog_visible"] for m in f["layout"]["maps"] for c in m["canvases"]]
                assert canvases, "Flight rendered no canvas"
                assert all(c["box"]["width"] > 200 and c["box"]["height"] > 150 for c in canvases), "Flight MapLibre canvas collapsed"
            await page.wait_for_timeout(3000)
            await capture(page, name + "-result", record)
            record["result_url"] = page.url
            record["result_has_public_address"] = "西新宿" in record["text"]
            if mode == "normal":
                assert record["result_has_public_address"], "No public address result after flight"
        record["status"] = "passed"
    except Exception as error:
        record["status"] = "failed"
        record["error"] = str(error)[:3000]
        try:
            await capture(page, name + "-failure", record)
        except Exception as capture_error:
            record["capture_error"] = str(capture_error)[:500]
    finally:
        await ctx.close()
        (OUT / "report.json").write_text(json.dumps(REPORT, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps({"case": name, "status": record.get("status"), "error": record.get("error")}, ensure_ascii=False), flush=True)


async def main():
    global AUTH_COOKIES
    async with async_playwright() as pw:
        for engine in ["chromium", "webkit"]:
            browser = await getattr(pw, engine).launch(args=["--enable-unsafe-swiftshader"] if engine == "chromium" else [])
            # 認証URLとCookieはログ・画像・証跡に保存しない。
            auth = await browser.new_context()
            auth_page = await auth.new_page()
            try:
                await auth_page.goto(os.environ["AUTH_URL"], wait_until="domcontentloaded", timeout=40000)
                if urlsplit(auth_page.url).hostname != urlsplit(URL).hostname:
                    raise RuntimeError("Deployment authentication did not reach review origin")
                AUTH_COOKIES = (await auth.storage_state())["cookies"]
            except Exception:
                raise RuntimeError("Deployment authentication failed; secret URL omitted") from None
            finally:
                await auth.close()
            sizes = [(375,667),(390,844),(402,874),(430,932),(844,390),(1024,768),(1440,900)] if engine == "chromium" else [(375,667),(390,844),(844,390)]
            for width, height in sizes:
                await case(browser, engine, f"{engine}-{width}x{height}", width, height)
            modes = ["normal", "touch_skip", "escape", "skip_enter", "skip_space", "reduced_initial", "reduced_during", "motion_off", "tile_failure", "text200", "keyboard"] if engine == "chromium" else ["normal", "escape", "skip_enter", "skip_space", "reduced_initial", "reduced_during"]
            for mode in modes:
                await case(browser, engine, f"{engine}-{mode}", mode=mode)
            await browser.close()
    failed = [x["name"] for x in REPORT["checks"] if x["status"] == "failed"]
    REPORT["failed_cases"] = failed
    (OUT / "report.json").write_text(json.dumps(REPORT, ensure_ascii=False, indent=2), encoding="utf-8")
    if failed:
        raise SystemExit("QA failures: " + ", ".join(failed))


asyncio.run(main())
